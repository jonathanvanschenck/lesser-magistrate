Lesser Magistrate LM board, version 1.1.0

Released from the KiCad project kicad/lm/ at git tag lm@1.1.0:
https://github.com/jonathanvanschenck/lesser-magistrate

Ordering: 2 layers, 1.6 mm FR4, lead-free HASL finish; board maker's defaults for everything else.

Files:
  lm-1.1.0-B_Cu.gbl          bottom copper (Gerber)
  lm-1.1.0-B_Mask.gbs        bottom solder mask (Gerber)
  lm-1.1.0-B_Silkscreen.gbo  bottom silkscreen (Gerber)
  lm-1.1.0-Edge_Cuts.gm1     board outline (Gerber)
  lm-1.1.0-F_Cu.gtl          top copper (Gerber)
  lm-1.1.0-F_Mask.gts        top solder mask (Gerber)
  lm-1.1.0-F_Silkscreen.gto  top silkscreen (Gerber)
  lm-1.1.0.d356              IPC-D-356 netlist, for the board maker's electrical test
  lm-1.1.0.drl               drill file (Excellon; plated and non-plated holes)

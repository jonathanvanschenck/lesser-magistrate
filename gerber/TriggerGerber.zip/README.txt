Lesser Magistrate Trigger board, version 1.0.1

Released from the KiCad project kicad/trigger/ at git tag trigger@1.0.1:
https://github.com/jonathanvanschenck/lesser-magistrate

Ordering: 2 layers, 1.6 mm FR4, lead-free HASL finish; board maker's defaults for everything else.

Files:
  trigger-1.0.1-B_Cu.gbl          bottom copper (Gerber)
  trigger-1.0.1-B_Mask.gbs        bottom solder mask (Gerber)
  trigger-1.0.1-B_Silkscreen.gbo  bottom silkscreen (Gerber)
  trigger-1.0.1-Edge_Cuts.gm1     board outline (Gerber)
  trigger-1.0.1-F_Cu.gtl          top copper (Gerber)
  trigger-1.0.1-F_Mask.gts        top solder mask (Gerber)
  trigger-1.0.1-F_Silkscreen.gto  top silkscreen (Gerber)
  trigger-1.0.1.d356              IPC-D-356 netlist, for the board maker's electrical test
  trigger-1.0.1.drl               drill file (Excellon; plated and non-plated holes)
